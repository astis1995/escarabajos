print("Getting imports")
import os
from tangent_utils import group_by_vertical, average_and_median_images
from stitching import stitch_images
from volume_reconstruction import load_panorama_slices, optimized_marching_cubes_to_trimesh
from poisson_reconstruction import poisson_reconstruct_external
#from preprocessing import mask_top_percentage
from preprocessing import process_folder
BASE_DIR = os.getcwd()
AVERAGE_DIR = os.path.join(BASE_DIR, "averaged_images")
STITCHED_DIR = os.path.join(BASE_DIR, "stitched")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
Y_CUT_DISTANCE_MM = 1.0
os.makedirs(STITCHED_DIR, exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)


from pathlib import Path
import os

def main():
    # Asegurar que las carpetas necesarias existen
    Path(OUTPUTS_DIR).mkdir(parents=True, exist_ok=True)
    Path(AVERAGE_DIR).mkdir(parents=True, exist_ok=True)
    Path(STITCHED_DIR).mkdir(parents=True, exist_ok=True)

    print("🔹 Agrupando imágenes .tif válidas...")
    groups = group_by_vertical(BASE_DIR)
    if not groups:
        print("❌ No se encontraron grupos de imágenes.")
        return

    print("🔹 Calculando promedios y medianas...")
    avg_paths, median_paths = average_and_median_images(groups, BASE_DIR, AVERAGE_DIR)
    if not avg_paths:
        print("❌ No se generaron imágenes promedio.")
        return
    
    #aplica las dos etapas de preprocessing
    print("🔹 Realizando filtrado por renormalización y gaussiano por cada valor vertical...")
    gauss_dir, image_paths_by_h = process_folder(groups, folder_path = median_paths)
    
    #con las 
    print("🔹 Realizando stitching horizontal por cada valor vertical...")
    stitch_images(image_paths_by_h, STITCHED_DIR, method="stitch_center",
                    overlap_pixels=20, center_offset=0, skew=10)

    print("🔹 Generando volumen 3D a partir de panoramas...")
    volume, slice_indices, max_h, max_w = load_panorama_slices(STITCHED_DIR)
    if volume is None or volume.size == 0:
        print("❌ No se pudo generar el volumen.")
        return

    print("🔹 Aplicando marching cubes optimizado...")
    mesh = optimized_marching_cubes_to_trimesh(
        volume,
        mm_per_pixel=2.3 / 512.0,
        mm_per_slice=Y_CUT_DISTANCE_MM,
        scale_factor=0.5,
        step_size=2,
        simplify_ratio=0.3
    )

    mc_path = Path(OUTPUTS_DIR) / "marching_cubes_mesh.stl"
    mesh.export(mc_path)
    print(f"✅ Malla optimizada guardada: {mc_path}")

    print("🔹 Reconstruyendo superficie externa (Poisson)...")
    out_path = Path(OUTPUTS_DIR) / "external_surface.stl"
    poisson_reconstruct_external(mc_path, out_path)

    print("✅ Todo finalizado correctamente.")

if __name__ == "__main__":
    main()
