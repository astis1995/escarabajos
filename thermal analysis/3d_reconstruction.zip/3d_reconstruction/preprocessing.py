import os
from image_processing import load_and_preprocess_image, noise_reduction
from curve_analysis import process_image_and_save  # usa el canvas actualizado
from collections import defaultdict

def process_folder(grouped_dict, folder_path):
    """
    Procesa todas las imágenes de una carpeta aplicando preprocesamiento,
    reducción de ruido, análisis de curva y filtrado gaussiano.

    Parámetros:
    - folder_path: ruta de la carpeta con las imágenes
    """
    if not os.path.exists(folder_path):
        raise ValueError(f"Carpeta no encontrada: {folder_path}")

    output_dir = os.path.join(folder_path, "processed_results")
    gauss_dir = os.path.join(folder_path, "gauss_filtered")
    
    #input_paths = {h: file_sub_dict["med_path"] for (v, h), file_sub_dict in grouped_dict.items()}
    image_paths_by_h = defaultdict(list)
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(gauss_dir, exist_ok=True)

    print(f"📁 Procesando carpeta: {folder_path}")
    
    for (v, h), file_sub_dict in grouped_dict.items():
        fname = file_sub_dict["med_path"].name
    #for fname in os.listdir(folder_path):
        if fname.lower().endswith(('.png', '.jpg', '.jpeg', '.tif')):
            img_path = os.path.join(folder_path, fname)
            try:
                processed_img_path = process_image_and_save(img_path, output_dir, gauss_dir)
                print(f"✅ Procesado: {fname}")
                #add image to grouped_dict
                element = v, processed_img_path
                image_paths_by_h[h].append(element)
                
            except Exception as e:
                print(f"⚠️ Error al procesar {fname}: {e}")
    return gauss_dir, image_paths_by_h