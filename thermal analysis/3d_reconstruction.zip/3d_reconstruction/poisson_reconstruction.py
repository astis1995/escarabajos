import trimesh
import pyvista as pv



def poisson_reconstruct_external(input_path, output_path, alpha=5.0):
    cloud = pv.read(input_path)

    # Usar n_cells en lugar de n_faces por advertencia de PyVista
    if cloud.n_cells == 0:
        print("⚠️ Nube de puntos detectada. Generando malla con Delaunay 3D...")

        # Generar una malla de tetraedros
        mesh = cloud.delaunay_3d(alpha=alpha)

        # Extraer la superficie (malla triangular)
        surface = mesh.extract_geometry()
    else:
        surface = cloud

    print("🔁 Calculando normales...")
    surface = surface.compute_normals(auto_orient_normals=True)

    print("💾 Guardando malla suavizada como STL...")
    surface.save(output_path)
    print(f"✅ Superficie externa reconstruida: {output_path}")

