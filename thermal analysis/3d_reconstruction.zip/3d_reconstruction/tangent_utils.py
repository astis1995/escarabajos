
import os
import re
import numpy as np
from PIL import Image
from collections import defaultdict

def list_valid_tif_files(base_folder):
    return [
        f for f in os.listdir(base_folder)
        if f.lower().endswith('.tif') and os.path.isfile(os.path.join(base_folder, f))
    ]

def extract_identifiers(filename):
    # Matches pattern: anything_XX-YY.tif where XX is vertical, YY is horizontal
    match = re.search(r'(\d+)-(\d+)', filename)
    if match:
        v = int(match.group(1))
        h = int(match.group(2))
        return v, h
    return None, None

def group_by_vertical(base_folder):
    grouped = defaultdict(list)
    for fname in list_valid_tif_files(base_folder):
        v, h = extract_identifiers(fname)
        if v is not None and h is not None:
            grouped[(v, h)].append(fname)
    return grouped

import os
from collections import defaultdict
from PIL import Image
import numpy as np

def compute_average_image(images, preserve_bitdepth=False):
    """Per-pixel average of a list of images (NumPy arrays), with better handling of bit-depth."""
    
    # Ensure images are in float for proper averaging
    avg_img = np.mean(images, axis=0)
    
    if preserve_bitdepth:
        # If you want to preserve higher bit-depths (e.g., uint16), return the average as uint16
        avg_img = np.clip(avg_img, 0, 65535).astype(np.uint16)  # or `np.uint16` to preserve range
    else:
        # Clip and convert to uint8 for images in that bit-depth
        avg_img = np.clip(avg_img, 0, 255).astype(np.uint8)

    return avg_img

def compute_median_image(images):
    """Median image based on total number of pixels (not pixel-wise median)."""
    # Sort images by number of pixels (width * height)
    sorted_images = sorted(images, key=lambda img: img.shape[0] * img.shape[1])
    n = len(sorted_images)
    if n % 2 == 1:
        return sorted_images[n // 2].astype(np.uint8)
    else:
        # Average the two median images
        img1 = sorted_images[n // 2 - 1]
        img2 = sorted_images[n // 2]
        avg_img = ((img1.astype(np.float32) + img2.astype(np.float32)) / 2.0)
        return np.clip(avg_img, 0, 255).astype(np.uint8)
from collections import defaultdict
from pathlib import Path
import numpy as np
from PIL import Image

from pathlib import Path
from collections import defaultdict
import numpy as np
from PIL import Image

def average_and_median_images(grouped_dict, base_folder, output_folder):
    base_folder = Path(base_folder)
    output_folder = Path(output_folder)

    avg_folder = output_folder / "average"
    med_folder = output_folder / "median"

    avg_folder.mkdir(parents=True, exist_ok=True)
    med_folder.mkdir(parents=True, exist_ok=True)

    averaged_paths = defaultdict(list)
    median_paths = defaultdict(list)

    for (v, h), file_list in grouped_dict.items():
        images = []
        for fname in file_list:
            path = base_folder / fname
            try:
                img = Image.open(path).convert('L')
                images.append(np.array(img, dtype=np.float32))
            except Exception as e:
                print(f"Failed to load {fname}: {e}")
        if not images:
            continue

        avg_img = compute_average_image(images)
        med_img = compute_median_image(images)

        avg_pil = Image.fromarray(avg_img)
        med_pil = Image.fromarray(med_img)

        avg_filename = f"{v:02d}-{h:02d}_avg.tif"
        med_filename = f"{v:02d}-{h:02d}_med.tif"

        avg_path = avg_folder / avg_filename
        med_path = med_folder / med_filename

        avg_pil.save(avg_path)
        med_pil.save(med_path)

        averaged_paths[v].append((h, str(avg_path)))
        median_paths[v].append((h, str(med_path)))
        
        #now for each (v, h) 
        file_sub_dict = {"file_list":file_list,
                         "avg_path":avg_path,
                         "med_path":med_path,
                            }
        #substitute file_list for file_sub_dict
        grouped_dict[v,h] = file_sub_dict

    return avg_folder, med_folder
