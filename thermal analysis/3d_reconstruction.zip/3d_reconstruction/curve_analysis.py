import cv2
import numpy as np
import json
import os

def fit_top_ridge_curve(img_gray, degree=2):
    h, w = img_gray.shape
    points_x, points_y = [], []

    for x in range(w):
        column = img_gray[:, x]
        y_indices = np.where(column > 5)[0]
        if len(y_indices) > 0:
            y_top = y_indices[0]
            points_x.append(x)
            points_y.append(y_top)

    points_x = np.array(points_x)
    points_y = np.array(points_y)

    coeffs = np.polyfit(points_x, points_y, degree)
    curve_fn = np.poly1d(coeffs)

    x_grid = np.linspace(0, w - 1, 1000)
    y_grid = curve_fn(x_grid)
    min_index = np.argmin(y_grid)
    x0 = x_grid[min_index]
    y0 = y_grid[min_index]

    dx = 1e-3
    dy = (curve_fn(x0 + dx) - curve_fn(x0 - dx)) / (2 * dx)
    tangent = np.array([1, dy]) / np.linalg.norm([1, dy])
    normal = np.array([-dy, 1]) / np.linalg.norm([-dy, 1])

    return curve_fn, x0, y0, tangent, normal
 
def gaussian_filter_column_based(img, poly_coeffs, sigma):
    filtered_img = np.zeros_like(img)
    rows, cols = img.shape

    for x in range(cols):
        y_center = int(np.polyval(poly_coeffs, x))
        for y in range(rows):
            gaussian_weight = np.exp(-((y - y_center) ** 2) / (2 * sigma ** 2))
            filtered_img[y, x] = img[y, x] * gaussian_weight

    return filtered_img.astype(np.uint8)

def save_processing_info(output_path, info):
    with open(output_path, 'w') as file:
        json.dump(info, file, indent=4)

def draw_curve_overlay(img, curve_fn, x0, y0, tangent, normal):
    img_rgb = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.circle(img_rgb, (int(x0), int(y0)), 4, (0, 0, 255), -1)
    cv2.line(img_rgb, (int(x0), int(y0)), (int(x0 + 40 * tangent[0]), int(y0 + 40 * tangent[1])), (255, 0, 0), 2)
    cv2.line(img_rgb, (int(x0), int(y0)), (int(x0 + 40 * normal[0]), int(y0 + 40 * normal[1])), (0, 255, 0), 2)

    for x in range(511):
        y1, y2 = int(curve_fn(x)), int(curve_fn(x + 1))
        if 0 <= y1 < 512 and 0 <= y2 < 512:
            cv2.line(img_rgb, (x, y1), (x + 1, y2), (255, 255, 0), 1)

    return img_rgb

def process_image_and_save(filepath, output_dir, gauss_dir, poly_degree=2, k=10, kernel_size=3, sigma=30):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    if not os.path.exists(gauss_dir):
        os.makedirs(gauss_dir)

    img_original = cv2.imread(filepath, cv2.IMREAD_GRAYSCALE)
    img_original = cv2.resize(img_original, (512, 512))
    
     # Convertir a negro el top k% antes de cualquier procesamiento
    top_k = int((k / 100) * img_original.shape[0])
    img_original[:top_k, :] = 0


    img_denoised = cv2.medianBlur(img_original, kernel_size)

    curve_fn, x0, y0, tangent, normal = fit_top_ridge_curve(img_denoised, degree=poly_degree)

    info = {
        "vertex": (int(x0), int(y0)),
        "normal_vector": normal.tolist(),
        "tangent_vector": tangent.tolist(),
        "polynomial_coefficients": curve_fn.coefficients.tolist(),
        "polynomial_degree": poly_degree
    }

    filename = os.path.basename(filepath)
    name, ext = os.path.splitext(filename)

    # Guardar info JSON
    save_processing_info(os.path.join(output_dir, name + '.json'), info)

    # Guardar imagen denoised
    denoised_with_curve = draw_curve_overlay(img_denoised, curve_fn, x0, y0, tangent, normal)
    cv2.imwrite(os.path.join(output_dir, f"denoised_{name}.png"), denoised_with_curve)

    # Filtrado gaussiano sobre la original
    img_gauss_filtered = gaussian_filter_column_based(img_original, curve_fn.coefficients, sigma)
    
    #segunda renormalizacion
    img_gauss_filtered_renormalized = cv2.medianBlur(img_gauss_filtered, kernel_size)
    
    # Guardar imagen filtrada 
    img_gauss_filtered_path = os.path.join(gauss_dir, f"gauss_renorm_{name}.png")
    cv2.imwrite(img_gauss_filtered_path, img_gauss_filtered_renormalized)
    
    # Superponer curva sobre la imagen filtrada
    gauss_with_curve = draw_curve_overlay(img_gauss_filtered, curve_fn, x0, y0, tangent, normal)
    cv2.imwrite(os.path.join(gauss_dir, f"gauss_and_curve_{name}.png"), gauss_with_curve)
    
    #return img_gauss_filtered path 
    return img_gauss_filtered_path